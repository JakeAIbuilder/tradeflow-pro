import { useState } from "react";
import { useLocation } from "wouter";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import MetricsCards from "@/components/dashboard/metrics-cards";
import JobsTable from "@/components/dashboard/jobs-table";
import LeadsList from "@/components/dashboard/leads-list";
import AiAutomation from "@/components/dashboard/ai-automation";
import MessagesList from "@/components/dashboard/messages-list";
import RoutePlanner from "@/components/dashboard/route-planner";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();
  
  // Render content based on current route
  const renderContent = () => {
    switch (location) {
      case "/leads":
        return <LeadsList />;
      case "/messages":
        return <MessagesList />;
      case "/ai":
        return <AiAutomation />;
      case "/analytics":
        return <RoutePlanner />;
      case "/settings":
        return (
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold mb-4">Settings</h3>
            <p className="text-muted-foreground">Settings page coming soon...</p>
          </div>
        );
      default:
        return <JobsTable />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 dark:bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-auto p-6">
          <MetricsCards />
          
          <div className="mt-8">
            <div className="bg-white dark:bg-card rounded-xl shadow-sm border border-border p-6">
              {renderContent()}
            </div>
          </div>

          {/* Secondary Grid - Leads and AI Status */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <div className="bg-white dark:bg-card rounded-xl shadow-sm border border-border p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-foreground">Active Leads</h3>
                <span className="text-sm text-muted-foreground">Quick View</span>
              </div>
              <LeadsList limit={3} />
            </div>

            <div className="bg-white dark:bg-card rounded-xl shadow-sm border border-border p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-foreground">AI Status</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full ai-pulse"></div>
                  <span className="text-sm text-green-600 font-medium">Active</span>
                </div>
              </div>
              <AiAutomation compact />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
