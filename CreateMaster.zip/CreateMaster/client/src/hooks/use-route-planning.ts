import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Job } from "@shared/schema";

interface RouteOptimizationRequest {
  jobIds: number[];
  date: string;
}

interface RouteOptimizationResponse {
  optimizedOrder: number[];
  totalDistance: number;
  totalDuration: number;
  jobs: Job[];
  estimatedFuelCost: number;
  legs: {
    distance: number;
    duration: number;
    startAddress: string;
    endAddress: string;
  }[];
}

interface GeocodeResponse {
  latitude: number;
  longitude: number;
  formattedAddress: string;
}

export function useOptimizeRoute() {
  return useMutation({
    mutationFn: async (data: RouteOptimizationRequest): Promise<RouteOptimizationResponse> => {
      return await apiRequest("POST", "/api/optimize-route", data);
    },
  });
}

export function useGeocodeAddress() {
  return useMutation({
    mutationFn: async (address: string): Promise<GeocodeResponse> => {
      return await apiRequest("POST", "/api/geocode", { address });
    },
  });
}

export function useGeocodeJob() {
  return useMutation({
    mutationFn: async (jobId: number): Promise<Job> => {
      return await apiRequest("PATCH", `/api/jobs/${jobId}/geocode`);
    },
  });
}

export function useRouteMetrics(date: string, jobs: Job[]) {
  return useQuery({
    queryKey: ["/api/route-metrics", date],
    queryFn: async () => {
      const dateJobs = jobs.filter(job => {
        if (!job.scheduledDate) return false;
        const jobDate = new Date(job.scheduledDate).toISOString().split('T')[0];
        return jobDate === date && job.status !== 'completed' && job.status !== 'cancelled';
      });

      const jobsWithLocation = dateJobs.filter(job => 
        job.latitude && job.longitude && job.address
      );

      const totalJobs = dateJobs.length;
      const jobsWithGPS = jobsWithLocation.length;
      const completionRate = totalJobs > 0 ? (jobsWithGPS / totalJobs) * 100 : 0;

      return {
        totalJobs,
        jobsWithGPS,
        completionRate,
        canOptimize: jobsWithGPS >= 2
      };
    },
    enabled: jobs.length > 0,
  });
}