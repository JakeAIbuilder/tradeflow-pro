import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { AiAutomation } from "@shared/schema";

export function useAi() {
  const [aiEnabled, setAiEnabled] = useState(true);

  const { data: automations } = useQuery<AiAutomation[]>({
    queryKey: ["/api/ai-automations"],
  });

  // Check if any automation is enabled
  useEffect(() => {
    if (automations) {
      const anyEnabled = automations.some(automation => automation.enabled);
      setAiEnabled(anyEnabled);
    }
  }, [automations]);

  const toggleAi = () => {
    setAiEnabled(!aiEnabled);
    // In a real implementation, this would update all automations
  };

  return {
    aiEnabled,
    toggleAi,
    automations,
  };
}

export function useAiAutomations() {
  return useQuery<AiAutomation[]>({
    queryKey: ["/api/ai-automations"],
  });
}

export function useUpdateAiAutomation() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, automation }: { id: number; automation: Partial<AiAutomation> }) => {
      const response = await apiRequest("PATCH", `/api/ai-automations/${id}`, automation);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-automations"] });
    },
  });
}

export function useDashboardMetrics() {
  return useQuery({
    queryKey: ["/api/dashboard/metrics"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
}
