import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Message, InsertMessage } from "@shared/schema";

export function useMessages() {
  return useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });
}

export function useMessage(id: number) {
  return useQuery<Message>({
    queryKey: ["/api/messages", id],
    enabled: !!id,
  });
}

export function useCreateMessage() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (message: InsertMessage) => {
      const response = await apiRequest("POST", "/api/messages", message);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
    },
  });
}

export function useGenerateQuote() {
  return useMutation({
    mutationFn: async (details: { service: string; description?: string; clientName: string }) => {
      const response = await apiRequest("POST", "/api/ai/generate-quote", details);
      return response.json();
    },
  });
}

export function useGenerateSchedule() {
  return useMutation({
    mutationFn: async (availableSlots: string[]) => {
      const response = await apiRequest("POST", "/api/ai/generate-schedule", { availableSlots });
      return response.json();
    },
  });
}
