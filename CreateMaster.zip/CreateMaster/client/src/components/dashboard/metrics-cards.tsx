import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import { 
  DollarSign, 
  CalendarCheck, 
  Reply, 
  Clock, 
  TrendingUp 
} from "lucide-react";

interface Metrics {
  revenue: number;
  revenueGrowth: number;
  jobsBooked: number;
  jobsGrowth: number;
  responseRate: number;
  aiImprovement: number;
  timeSaved: string;
  conversionRate: number;
}

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery<Metrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-16 mb-2" />
              <Skeleton className="h-3 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!metrics) return null;

  const cards = [
    {
      title: "Monthly Revenue",
      value: formatCurrency(metrics.revenue),
      change: `+${metrics.revenueGrowth}%`,
      changeText: "from last month",
      icon: DollarSign,
      iconBg: "bg-blue-100 dark:bg-blue-900",
      iconColor: "text-blue-600 dark:text-blue-300",
    },
    {
      title: "Jobs Booked",
      value: metrics.jobsBooked.toString(),
      change: `+${metrics.jobsGrowth}%`,
      changeText: "from last month",
      icon: CalendarCheck,
      iconBg: "bg-green-100 dark:bg-green-900",
      iconColor: "text-green-600 dark:text-green-300",
    },
    {
      title: "Response Rate",
      value: `${metrics.responseRate}%`,
      change: `+${metrics.aiImprovement}%`,
      changeText: "AI improved by",
      icon: Reply,
      iconBg: "bg-purple-100 dark:bg-purple-900",
      iconColor: "text-purple-600 dark:text-purple-300",
    },
    {
      title: "Time Saved",
      value: `${metrics.timeSaved}h`,
      change: "AI automation",
      changeText: "Thanks to",
      icon: Clock,
      iconBg: "bg-orange-100 dark:bg-orange-900",
      iconColor: "text-orange-600 dark:text-orange-300",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className="metric-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {card.title}
                  </p>
                  <p className="text-3xl font-bold text-foreground mt-1">
                    {card.value}
                  </p>
                  <p className="text-sm text-green-600 dark:text-green-400 mt-2 flex items-center">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    <span className="font-medium">{card.change}</span>
                    <span className="ml-1 text-muted-foreground">{card.changeText}</span>
                  </p>
                </div>
                <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`h-6 w-6 ${card.iconColor}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
