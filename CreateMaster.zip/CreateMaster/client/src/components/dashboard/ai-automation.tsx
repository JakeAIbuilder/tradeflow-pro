import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { AiAutomation } from "@shared/schema";
import { Bot, FileText, Calendar, Settings, Edit } from "lucide-react";

interface AiAutomationProps {
  compact?: boolean;
}

export default function AiAutomation({ compact = false }: AiAutomationProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: automations, isLoading } = useQuery<AiAutomation[]>({
    queryKey: ["/api/ai-automations"],
  });

  const updateAutomationMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => {
      const response = await apiRequest("PATCH", `/api/ai-automations/${id}`, { enabled });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-automations"] });
      toast({
        title: "Success",
        description: "AI automation updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update AI automation",
        variant: "destructive",
      });
    },
  });

  const handleToggle = (id: number, enabled: boolean) => {
    updateAutomationMutation.mutate({ id, enabled });
  };

  const getAutomationIcon = (type: string) => {
    switch (type) {
      case "auto_response":
        return Bot;
      case "quote_generation":
        return FileText;
      case "scheduling":
        return Calendar;
      default:
        return Bot;
    }
  };

  const getAutomationColor = (type: string) => {
    switch (type) {
      case "auto_response":
        return { bg: "bg-green-50 dark:bg-green-950", border: "border-green-200 dark:border-green-800", text: "text-green-600 dark:text-green-300" };
      case "quote_generation":
        return { bg: "bg-blue-50 dark:bg-blue-950", border: "border-blue-200 dark:border-blue-800", text: "text-blue-600 dark:text-blue-300" };
      case "scheduling":
        return { bg: "bg-purple-50 dark:bg-purple-950", border: "border-purple-200 dark:border-purple-800", text: "text-purple-600 dark:text-purple-300" };
      default:
        return { bg: "bg-gray-50 dark:bg-gray-950", border: "border-gray-200 dark:border-gray-800", text: "text-gray-600 dark:text-gray-300" };
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: compact ? 2 : 3 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-6 h-6" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                </div>
                <Skeleton className="w-10 h-6" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const displayAutomations = compact ? automations?.slice(0, 3) : automations;

  return (
    <div className="space-y-4">
      {displayAutomations?.map((automation) => {
        const Icon = getAutomationIcon(automation.type);
        const colors = getAutomationColor(automation.type);
        
        return (
          <Card key={automation.id} className={`${colors.bg} ${colors.border} border`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Icon className={`h-5 w-5 ${colors.text}`} />
                  <div>
                    <p className={`font-medium ${colors.text}`}>{automation.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {automation.type === "auto_response" && "Responding to new leads instantly"}
                      {automation.type === "quote_generation" && "Creating accurate quotes automatically"}
                      {automation.type === "scheduling" && "Optimizing appointment booking"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {!compact && (
                    <div className="text-right mr-3">
                      <p className={`text-sm font-medium ${colors.text}`}>
                        {automation.successRate ? `${automation.successRate}%` : 'N/A'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {automation.usageCount || 0} uses
                      </p>
                    </div>
                  )}
                  <Switch
                    checked={automation.enabled}
                    onCheckedChange={(enabled) => handleToggle(automation.id, enabled)}
                    disabled={updateAutomationMutation.isPending}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {!compact && (
        <div className="pt-4 border-t border-border">
          <p className="text-sm font-medium text-foreground mb-3">Quick Actions</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" size="sm" className="justify-start">
              <Edit className="h-4 w-4 mr-2" />
              Edit Templates
            </Button>
            <Button variant="outline" size="sm" className="justify-start">
              <Settings className="h-4 w-4 mr-2" />
              AI Settings
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
