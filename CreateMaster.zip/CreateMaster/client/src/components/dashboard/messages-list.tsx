import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDateTime, getTimeAgo } from "@/lib/utils";
import type { Message } from "@shared/schema";
import { Reply, Eye, Bot, User } from "lucide-react";

export default function MessagesList() {
  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-9 w-20" />
        </div>
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-start space-x-4 p-4 bg-muted rounded-lg">
            <Skeleton className="w-10 h-10 rounded-full" />
            <div className="flex-1 space-y-2">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-5 w-16" />
              </div>
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-3 w-3/4" />
              <Skeleton className="h-3 w-20" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Recent Messages</h3>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>

      <div className="space-y-4">
        {messages?.map((message) => (
          <div key={message.id} className="flex items-start space-x-4 p-4 bg-muted rounded-lg">
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarFallback className={
                message.type === "ai_sent" 
                  ? "bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300"
                  : "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300"
              }>
                {message.type === "ai_sent" ? (
                  <Bot className="h-4 w-4" />
                ) : (
                  <User className="h-4 w-4" />
                )}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <p className="font-medium text-foreground">{message.sender}</p>
                <div className="flex items-center space-x-2">
                  <Badge
                    variant={message.type === "ai_sent" ? "default" : "secondary"}
                    className={
                      message.type === "ai_sent"
                        ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                        : "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                    }
                  >
                    {message.type === "ai_sent" ? "AI Sent" : 
                     message.type === "ai_generated" ? "AI Generated" : "Manual"}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {getTimeAgo(message.createdAt || new Date())}
                  </span>
                </div>
              </div>
              {message.subject && (
                <p className="text-sm font-medium text-foreground mb-1">
                  {message.subject}
                </p>
              )}
              <p className="text-sm text-muted-foreground line-clamp-3">
                {message.content}
              </p>
              <div className="flex items-center space-x-3 mt-2">
                <Button variant="ghost" size="sm" className="text-xs text-primary hover:text-primary">
                  <Reply className="h-3 w-3 mr-1" />
                  Reply
                </Button>
                <Button variant="ghost" size="sm" className="text-xs text-muted-foreground hover:text-foreground">
                  <Eye className="h-3 w-3 mr-1" />
                  View Full
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
