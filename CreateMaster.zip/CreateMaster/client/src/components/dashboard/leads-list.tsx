import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, getInitials, getStatusColor, getStatusLabel, getTimeAgo } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import type { Lead } from "@shared/schema";
import { ArrowRight, UserCheck } from "lucide-react";

interface LeadsListProps {
  limit?: number;
}

export default function LeadsList({ limit }: LeadsListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: leads, isLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const convertLeadMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/leads/${id}/convert`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      toast({
        title: "Success",
        description: "Lead converted to job successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to convert lead to job",
        variant: "destructive",
      });
    },
  });

  const handleConvertLead = (id: number) => {
    convertLeadMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: limit || 5 }).map((_, i) => (
          <div key={i} className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Skeleton className="w-10 h-10 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-48" />
                <Skeleton className="h-3 w-24" />
              </div>
            </div>
            <div className="text-right space-y-2">
              <Skeleton className="h-5 w-16" />
              <Skeleton className="h-3 w-20" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  const displayLeads = limit ? leads?.slice(0, limit) : leads;

  return (
    <div className="space-y-4">
      {displayLeads?.map((lead) => (
        <div key={lead.id} className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="gradient-blue text-white text-sm">
                {getInitials(lead.name)}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-foreground">{lead.name}</p>
              <p className="text-sm text-muted-foreground">
                {lead.service} - {lead.estimatedValue ? formatCurrency(lead.estimatedValue) : 'Quote needed'}
              </p>
              <p className="text-xs text-muted-foreground">
                From {lead.source || 'Unknown'} • {getTimeAgo(lead.createdAt || new Date())}
              </p>
            </div>
          </div>
          <div className="text-right space-y-2">
            <div className="flex items-center space-x-2">
              <Badge className={`status-badge ${getStatusColor(lead.status)}`}>
                {getStatusLabel(lead.status)}
              </Badge>
              {lead.status !== 'converted' && lead.status !== 'lost' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleConvertLead(lead.id)}
                  disabled={convertLeadMutation.isPending}
                  className="text-xs"
                >
                  <UserCheck className="h-3 w-3 mr-1" />
                  Convert
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Response: {lead.responseRate || 0}%
            </p>
          </div>
        </div>
      ))}

      {!limit && (
        <Button variant="ghost" className="w-full text-primary hover:text-primary">
          View All Leads <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      )}
    </div>
  );
}
