import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useAi } from "@/hooks/use-ai";
import { 
  LayoutDashboard, 
  Briefcase, 
  Users, 
  MessageSquare, 
  Bot, 
  BarChart3, 
  Settings, 
  X 
} from "lucide-react";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export default function Sidebar({ open, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { aiEnabled, toggleAi } = useAi();

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard, badge: null },
    { name: "Jobs", href: "/jobs", icon: Briefcase, badge: "8" },
    { name: "Leads", href: "/leads", icon: Users, badge: "12" },
    { name: "Messages", href: "/messages", icon: MessageSquare, badge: "3" },
    { name: "AI Automation", href: "/ai", icon: Bot, badge: null },
    { name: "Analytics", href: "/analytics", icon: BarChart3, badge: null },
    { name: "Settings", href: "/settings", icon: Settings, badge: null },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div 
          className="lg:hidden fixed inset-0 z-50 bg-slate-600 bg-opacity-75"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 flex flex-col w-72 bg-white dark:bg-card border-r border-border transition-transform duration-300 ease-in-out",
        open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo Section */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 gradient-blue rounded-lg flex items-center justify-center">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <span className="text-xl font-bold text-foreground">TradeFlow Pro</span>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1 rounded-md text-muted-foreground hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors",
                  isActive
                    ? "text-white bg-gradient-to-r from-blue-500 to-blue-600"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <Icon className={cn(
                  "mr-3 h-4 w-4",
                  isActive ? "text-blue-100" : "text-muted-foreground"
                )} />
                {item.name}
                {item.badge && (
                  <Badge 
                    variant={isActive ? "secondary" : "default"} 
                    className={cn(
                      "ml-auto text-xs",
                      isActive 
                        ? "bg-blue-100 text-blue-600" 
                        : "bg-primary text-primary-foreground"
                    )}
                  >
                    {item.badge}
                  </Badge>
                )}
              </Link>
            );
          })}
        </nav>

        {/* AI Status Indicator */}
        <div className="px-4 py-4 border-t border-border">
          <div className={cn(
            "flex items-center justify-between p-3 rounded-lg",
            aiEnabled ? "bg-green-50 dark:bg-green-950" : "bg-gray-50 dark:bg-gray-900"
          )}>
            <div className="flex items-center space-x-3">
              <div className={cn(
                "w-2 h-2 rounded-full",
                aiEnabled ? "bg-green-400 ai-pulse" : "bg-gray-400"
              )} />
              <span className={cn(
                "text-sm font-medium",
                aiEnabled ? "text-green-700 dark:text-green-300" : "text-gray-700 dark:text-gray-300"
              )}>
                AI {aiEnabled ? "Active" : "Inactive"}
              </span>
            </div>
            <Switch
              checked={aiEnabled}
              onCheckedChange={toggleAi}
              className="data-[state=checked]:bg-green-400"
            />
          </div>
        </div>
      </div>
    </>
  );
}
