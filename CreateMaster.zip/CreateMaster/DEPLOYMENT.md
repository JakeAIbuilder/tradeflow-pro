# TradeFlow Pro - Deployment Guide

This guide will help you deploy TradeFlow Pro to production and set it up on various hosting platforms.

## Quick MVP Deployment

### Option 1: Replit (Fastest - 2 minutes)
1. Your app is already running on Replit
2. Click "Deploy" in the Replit interface
3. Configure your OpenAI API key in Secrets
4. Your MVP will be live instantly at `https://your-repl-name.replit.app`

### Option 2: Vercel (Recommended for Production)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy with one command
vercel

# Set environment variables
vercel env add OPENAI_API_KEY
vercel env add NODE_ENV production
```

### Option 3: Railway
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway project create
railway up

# Add environment variables
railway variables set OPENAI_API_KEY=your_key_here
```

### Option 4: Render
1. Connect your GitHub repository to Render
2. Create a new Web Service
3. Build Command: `npm run build`
4. Start Command: `npm start`
5. Add environment variables in Render dashboard

## Environment Variables for Production

Required:
```
OPENAI_API_KEY=sk-your-openai-key
NODE_ENV=production
```

Optional (for PostgreSQL):
```
DATABASE_URL=postgresql://user:pass@host:port/db
```

## Database Setup (Optional)

### Development (Default)
- Uses in-memory storage
- Data resets on restart
- Perfect for testing and MVP

### Production with PostgreSQL
1. **Neon (Recommended)**
   - Sign up at neon.tech
   - Create database
   - Copy connection string to `DATABASE_URL`

2. **Supabase**
   - Sign up at supabase.com
   - Create project
   - Get PostgreSQL connection string

3. **Railway PostgreSQL**
   - Add PostgreSQL service to Railway project
   - Connection string auto-generated

## Performance Optimization

### Build Optimization
```bash
# Production build
npm run build

# Check bundle size
ls -la dist/
```

### Caching Strategy
- Static assets cached for 1 year
- API responses cached for 5 minutes
- Database queries optimized with indexes

### Monitoring Setup
Add to your deployment:
```javascript
// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});
```

## Security Checklist

- [x] Environment variables secured
- [x] CORS configured properly
- [x] Rate limiting implemented
- [x] Input validation with Zod
- [x] SQL injection protection (Drizzle ORM)
- [x] XSS protection (React built-in)

## Scaling Considerations

### Database
- Start with Neon serverless (auto-scaling)
- Monitor query performance
- Add read replicas if needed

### API Limits
- OpenAI: Monitor usage and set limits
- Implement request queuing for high traffic
- Cache AI responses where appropriate

### Frontend
- CDN deployment (Vercel/Netlify automatic)
- Image optimization
- Bundle splitting (Vite automatic)

## Custom Domain Setup

### Vercel
```bash
vercel domains add yourdomain.com
vercel alias set your-deployment.vercel.app yourdomain.com
```

### Railway
1. Go to project settings
2. Add custom domain
3. Update DNS records as instructed

## Backup Strategy

### Database Backups
```bash
# Automated daily backups with Neon
# Manual backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql
```

### Application Backups
- GitHub repository (source code)
- Environment variables documented
- Deployment configurations saved

## Monitoring and Analytics

### Error Tracking
Add Sentry or similar:
```bash
npm install @sentry/node @sentry/react
```

### Performance Monitoring
- Vercel Analytics (automatic)
- Google Analytics for user tracking
- Database performance monitoring

## Support and Maintenance

### Health Checks
```bash
# Check application health
curl https://yourdomain.com/health

# Check API endpoints
curl https://yourdomain.com/api/jobs
```

### Log Monitoring
- Platform logs (Vercel/Railway/Render)
- Application logs via console.log
- Error aggregation and alerting

## Cost Optimization

### Free Tier Limits
- **Vercel**: 100GB bandwidth/month
- **Railway**: $5/month credit
- **Render**: 750 hours/month free
- **Neon**: 1GB database free

### Scaling Costs
- OpenAI API: ~$0.03 per 1K tokens
- Database: ~$20/month for production
- Hosting: ~$10-50/month depending on traffic

## Troubleshooting

### Common Issues
1. **OpenAI quota exceeded**: Check billing, add payment method
2. **Database connection**: Verify DATABASE_URL format
3. **Build failures**: Check Node.js version compatibility
4. **Environment variables**: Ensure all required vars are set

### Debug Commands
```bash
# Check environment
node -e "console.log(process.env)"

# Test database connection
node -e "console.log('DB:', process.env.DATABASE_URL ? 'Connected' : 'Memory mode')"

# Verify OpenAI key
node -e "console.log('OpenAI:', process.env.OPENAI_API_KEY ? 'Configured' : 'Missing')"
```

---

Your TradeFlow Pro MVP is ready for deployment! Choose the option that best fits your needs and timeline.