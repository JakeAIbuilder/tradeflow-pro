# TradeFlow Pro - AI-Powered Business Management for Tradesmen

TradeFlow Pro is a comprehensive business management platform designed specifically for tradesmen and service businesses. It combines job tracking, lead management, and AI-powered customer communication to streamline operations and grow your business.

## Features

### 🔧 Job Management
- Complete job lifecycle tracking (scheduled → in progress → completed)
- Client information and service details
- Automated scheduling and calendar integration
- Revenue tracking and job analytics

### 👥 Lead Management
- Intelligent lead capture and qualification
- Source tracking (Google Ads, Facebook, referrals, website)
- Automated lead conversion to jobs
- Response rate monitoring

### 🤖 AI Automation
- Instant automated responses to new inquiries
- Professional quote generation
- Smart scheduling assistance
- Template customization for different scenarios

### 📊 Business Analytics
- Real-time revenue tracking
- Job completion rates
- AI performance metrics
- Time saved through automation

## Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: OpenAI GPT-4o integration
- **UI**: Tailwind CSS + Shadcn/ui components
- **State Management**: TanStack Query

## Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL database (or use the included memory storage for development)
- OpenAI API key

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/tradeflow-pro.git
   cd tradeflow-pro
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and add your configuration:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   DATABASE_URL=your_postgresql_url_here  # Optional for development
   NODE_ENV=development
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:5000`

## Deployment

### Environment Variables Required
- `OPENAI_API_KEY` - Your OpenAI API key for AI features
- `DATABASE_URL` - PostgreSQL connection string (optional, uses memory storage by default)
- `NODE_ENV` - Set to "production" for production builds

### Build for Production
```bash
npm run build
npm start
```

## API Endpoints

### Jobs
- `GET /api/jobs` - List all jobs
- `POST /api/jobs` - Create new job
- `PATCH /api/jobs/:id` - Update job
- `DELETE /api/jobs/:id` - Delete job

### Leads
- `GET /api/leads` - List all leads
- `POST /api/leads` - Create new lead (triggers AI automation)
- `PATCH /api/leads/:id` - Update lead
- `POST /api/leads/:id/convert` - Convert lead to job

### AI Features
- `POST /api/ai/generate-quote` - Generate AI quote
- `POST /api/ai/generate-schedule` - Generate scheduling message
- `GET /api/ai-automations` - List automation settings
- `PATCH /api/ai-automations/:id` - Update automation

### Analytics
- `GET /api/dashboard/metrics` - Business metrics and KPIs

## Features in Detail

### AI Automation System
The platform includes three main AI automation types:

1. **Auto Response** - Instantly responds to new leads with personalized messages
2. **Quote Generation** - Creates professional estimates based on service requirements
3. **Smart Scheduling** - Suggests optimal appointment times and handles booking

### Lead-to-Job Conversion
Seamlessly convert qualified leads into scheduled jobs with one click, automatically transferring all relevant information and maintaining communication history.

### Real-time Metrics
Track key business indicators including:
- Monthly revenue and growth
- Job completion rates
- AI response effectiveness
- Time saved through automation

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions, please open an issue on GitHub or contact us at support@tradeflowpro.com

---

Built with ❤️ for the trades industry