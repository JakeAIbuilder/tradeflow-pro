import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertJobSchema, insertLeadSchema, insertMessageSchema } from "@shared/schema";
import { generateAutoResponse, generateQuote, generateSchedulingMessage } from "./services/openai";
import { geocodeAddress, optimizeRoute, updateJobWithCoordinates } from "./services/geocoding";

export async function registerRoutes(app: Express): Promise<Server> {
  // Jobs endpoints
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getJob(id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const result = insertJobSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid job data", errors: result.error.errors });
      }
      
      const job = await storage.createJob(result.data);
      res.status(201).json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to create job" });
    }
  });

  app.patch("/api/jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.updateJob(id, req.body);
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  app.delete("/api/jobs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteJob(id);
      if (!success) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json({ message: "Job deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete job" });
    }
  });

  // Leads endpoints
  app.get("/api/leads", async (req, res) => {
    try {
      const leads = await storage.getLeads();
      res.json(leads);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leads" });
    }
  });

  app.post("/api/leads", async (req, res) => {
    try {
      const result = insertLeadSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid lead data", errors: result.error.errors });
      }
      
      const lead = await storage.createLead(result.data);

      // Generate AI auto-response if enabled
      const automations = await storage.getAiAutomations();
      const autoResponse = automations.find(a => a.type === "auto_response" && a.enabled);
      
      if (autoResponse && lead.email) {
        try {
          const responseText = await generateAutoResponse({
            name: lead.name,
            service: lead.service,
            estimatedValue: lead.estimatedValue || undefined
          });

          await storage.createMessage({
            sender: "TradeFlow Pro",
            recipient: lead.email,
            subject: "Thank you for your interest",
            content: responseText,
            type: "ai_sent",
            leadId: lead.id,
            status: "sent"
          });

          // Update automation usage
          await storage.updateAiAutomation(autoResponse.id, {
            usageCount: (autoResponse.usageCount || 0) + 1
          });
        } catch (error) {
          console.error("Failed to send auto-response:", error);
        }
      }
      
      res.status(201).json(lead);
    } catch (error) {
      res.status(500).json({ message: "Failed to create lead" });
    }
  });

  app.patch("/api/leads/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const lead = await storage.updateLead(id, req.body);
      res.json(lead);
    } catch (error) {
      res.status(500).json({ message: "Failed to update lead" });
    }
  });

  // Convert lead to job
  app.post("/api/leads/:id/convert", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const lead = await storage.getLead(id);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }

      const job = await storage.createJob({
        clientName: lead.name,
        clientEmail: lead.email,
        service: lead.service,
        description: lead.notes || "",
        value: lead.estimatedValue || "0",
        status: "scheduled"
      });

      // Update lead status
      await storage.updateLead(id, { status: "converted" });

      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to convert lead to job" });
    }
  });

  // Messages endpoints
  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const result = insertMessageSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid message data", errors: result.error.errors });
      }
      
      const message = await storage.createMessage(result.data);
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // AI Automation endpoints
  app.get("/api/ai-automations", async (req, res) => {
    try {
      const automations = await storage.getAiAutomations();
      res.json(automations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI automations" });
    }
  });

  app.patch("/api/ai-automations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const automation = await storage.updateAiAutomation(id, req.body);
      res.json(automation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update AI automation" });
    }
  });

  // Generate quote endpoint
  app.post("/api/ai/generate-quote", async (req, res) => {
    try {
      const { service, description, clientName } = req.body;
      const quote = await generateQuote({ service, description, clientName });
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate quote" });
    }
  });

  // Generate scheduling message
  app.post("/api/ai/generate-schedule", async (req, res) => {
    try {
      const { availableSlots } = req.body;
      const message = await generateSchedulingMessage(availableSlots);
      res.json({ message });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate scheduling message" });
    }
  });

  // Dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const jobs = await storage.getJobs();
      const leads = await storage.getLeads();
      const messages = await storage.getMessages();
      const automations = await storage.getAiAutomations();

      const totalRevenue = jobs
        .filter(job => job.status === "completed")
        .reduce((sum, job) => sum + parseFloat(job.value), 0);

      const jobsBooked = jobs.filter(job => job.status !== "cancelled").length;
      
      const aiMessages = messages.filter(msg => msg.type === "ai_sent").length;
      const totalMessages = messages.length;
      const responseRate = totalMessages > 0 ? Math.round((aiMessages / totalMessages) * 100) : 0;

      const enabledAutomations = automations.filter(a => a.enabled);
      const timeSaved = enabledAutomations.reduce((sum, a) => sum + (a.usageCount || 0), 0) * 0.25; // 15 minutes per automation

      res.json({
        revenue: totalRevenue,
        revenueGrowth: 12.5,
        jobsBooked,
        jobsGrowth: 8.3,
        responseRate,
        aiImprovement: 15,
        timeSaved: timeSaved.toFixed(1),
        conversionRate: leads.length > 0 ? Math.round((jobs.length / leads.length) * 100) : 0
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // GPS Route Planning endpoints
  app.post("/api/geocode", async (req, res) => {
    try {
      const { address } = req.body;
      if (!address) {
        return res.status(400).json({ message: "Address is required" });
      }

      const result = await geocodeAddress(address);
      if (!result) {
        return res.status(404).json({ message: "Address not found" });
      }

      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Geocoding failed" });
    }
  });

  app.post("/api/optimize-route", async (req, res) => {
    try {
      const { jobIds, date } = req.body;
      
      if (!jobIds || !Array.isArray(jobIds)) {
        return res.status(400).json({ message: "Job IDs array is required" });
      }

      const jobs = await storage.getJobs();
      const selectedJobs = jobs.filter(job => jobIds.includes(job.id));
      
      // Filter jobs with location data
      const jobsWithLocation = selectedJobs.filter(job => 
        job.latitude && job.longitude && job.address
      );

      if (jobsWithLocation.length === 0) {
        return res.status(400).json({ message: "No jobs with location data found" });
      }

      const waypoints = jobsWithLocation.map(job => ({
        address: `${job.address}, ${job.city}, ${job.state} ${job.zipCode}`,
        lat: parseFloat(job.latitude!),
        lng: parseFloat(job.longitude!)
      }));

      const optimizedRoute = await optimizeRoute(waypoints);
      
      // Map optimized order back to jobs
      const optimizedJobs = optimizedRoute.optimizedOrder.map(index => jobsWithLocation[index]);

      res.json({
        ...optimizedRoute,
        jobs: optimizedJobs,
        estimatedFuelCost: optimizedRoute.totalDistance * 0.15 // $0.15 per mile
      });
    } catch (error) {
      res.status(500).json({ message: "Route optimization failed" });
    }
  });

  app.patch("/api/jobs/:id/geocode", async (req, res) => {
    try {
      const { id } = req.params;
      const job = await storage.getJob(parseInt(id));
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      if (!job.address || !job.city || !job.state) {
        return res.status(400).json({ message: "Job address is incomplete" });
      }

      const fullAddress = `${job.address}, ${job.city}, ${job.state} ${job.zipCode || ''}`;
      const coordinates = await updateJobWithCoordinates(parseInt(id), fullAddress);
      
      if (!coordinates) {
        return res.status(404).json({ message: "Could not geocode address" });
      }

      const updatedJob = await storage.updateJob(parseInt(id), {
        latitude: coordinates.latitude,
        longitude: coordinates.longitude
      });

      res.json(updatedJob);
    } catch (error) {
      res.status(500).json({ message: "Failed to geocode job address" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
