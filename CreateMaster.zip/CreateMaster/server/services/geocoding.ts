// Simple geocoding service that doesn't require API keys for basic functionality
// Uses OpenStreetMap Nominatim for address geocoding

interface GeocodeResult {
  latitude: number;
  longitude: number;
  formattedAddress: string;
}

interface RouteOptimizationResult {
  optimizedOrder: number[];
  totalDistance: number;
  totalDuration: number;
  legs: {
    distance: number;
    duration: number;
    startAddress: string;
    endAddress: string;
  }[];
}

export async function geocodeAddress(address: string): Promise<GeocodeResult | null> {
  try {
    // Use OpenStreetMap Nominatim API (free, no API key required)
    const encodedAddress = encodeURIComponent(address);
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}&limit=1&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'TradeFlow-Pro/1.0'
        }
      }
    );

    if (!response.ok) {
      console.warn('Geocoding API request failed:', response.status);
      return null;
    }

    const data = await response.json();
    
    if (!data || data.length === 0) {
      console.warn('No geocoding results found for address:', address);
      return null;
    }

    const result = data[0];
    return {
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon),
      formattedAddress: result.display_name
    };
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
}

export async function optimizeRoute(waypoints: { address: string; lat: number; lng: number }[]): Promise<RouteOptimizationResult> {
  if (waypoints.length <= 1) {
    return {
      optimizedOrder: [0],
      totalDistance: 0,
      totalDuration: 0,
      legs: []
    };
  }

  try {
    // Simple nearest neighbor algorithm for route optimization
    // In production, you could use Google Maps Directions API or similar
    const optimized = optimizeWithNearestNeighbor(waypoints);
    
    // Calculate distances using Haversine formula
    const legs = [];
    let totalDistance = 0;
    let totalDuration = 0;

    for (let i = 0; i < optimized.length - 1; i++) {
      const current = waypoints[optimized[i]];
      const next = waypoints[optimized[i + 1]];
      
      const distance = calculateDistance(
        current.lat, current.lng,
        next.lat, next.lng
      );
      
      // Estimate duration based on distance (average 30 mph in city)
      const duration = (distance / 30) * 60; // minutes
      
      legs.push({
        distance: Math.round(distance * 100) / 100,
        duration: Math.round(duration),
        startAddress: current.address,
        endAddress: next.address
      });
      
      totalDistance += distance;
      totalDuration += duration;
    }

    return {
      optimizedOrder: optimized,
      totalDistance: Math.round(totalDistance * 100) / 100,
      totalDuration: Math.round(totalDuration),
      legs
    };
  } catch (error) {
    console.error('Route optimization error:', error);
    // Return original order if optimization fails
    return {
      optimizedOrder: waypoints.map((_, index) => index),
      totalDistance: 0,
      totalDuration: 0,
      legs: []
    };
  }
}

function optimizeWithNearestNeighbor(waypoints: { lat: number; lng: number }[]): number[] {
  if (waypoints.length <= 1) return [0];
  
  const unvisited = new Set(waypoints.map((_, index) => index));
  const route = [0]; // Start with first waypoint
  unvisited.delete(0);
  
  let current = 0;
  
  while (unvisited.size > 0) {
    let nearest = -1;
    let minDistance = Infinity;
    
    for (const candidate of Array.from(unvisited)) {
      const distance = calculateDistance(
        waypoints[current].lat, waypoints[current].lng,
        waypoints[candidate].lat, waypoints[candidate].lng
      );
      
      if (distance < minDistance) {
        minDistance = distance;
        nearest = candidate;
      }
    }
    
    if (nearest !== -1) {
      route.push(nearest);
      unvisited.delete(nearest);
      current = nearest;
    } else {
      break;
    }
  }
  
  return route;
}

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);
  
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export async function updateJobWithCoordinates(jobId: number, address: string) {
  const geocodeResult = await geocodeAddress(address);
  
  if (geocodeResult) {
    return {
      latitude: geocodeResult.latitude.toString(),
      longitude: geocodeResult.longitude.toString(),
      formattedAddress: geocodeResult.formattedAddress
    };
  }
  
  return null;
}