import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export async function generateAutoResponse(leadDetails: {
  name: string;
  service: string;
  estimatedValue?: string;
}): Promise<string> {
  try {
    const prompt = `Generate a professional auto-response message for a tradesman business. 
    Lead details:
    - Name: ${leadDetails.name}
    - Service requested: ${leadDetails.service}
    - Estimated value: ${leadDetails.estimatedValue || 'Not specified'}
    
    Create a warm, professional response that:
    1. Thanks them for their interest
    2. Confirms the service they're interested in
    3. Mentions we'll get back to them with a detailed quote
    4. Keeps it concise and friendly
    
    Return only the message text, no quotes or formatting.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 200,
    });

    return response.choices[0].message.content || "Thank you for your interest! We'll get back to you soon with a detailed quote.";
  } catch (error) {
    console.error("Error generating auto response:", error);
    return "Thank you for your interest in our services. We'll get back to you within 24 hours with a detailed quote.";
  }
}

export async function generateQuote(serviceDetails: {
  service: string;
  description?: string;
  clientName: string;
}): Promise<{
  quote: number;
  breakdown: string;
  timeline: string;
}> {
  try {
    const prompt = `Generate a realistic quote for a tradesman service. 
    Service details:
    - Service: ${serviceDetails.service}
    - Description: ${serviceDetails.description || 'Standard service'}
    - Client: ${serviceDetails.clientName}
    
    Provide a JSON response with:
    {
      "quote": <number representing dollar amount>,
      "breakdown": "<detailed breakdown of costs>",
      "timeline": "<estimated completion time>"
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional tradesman with 15+ years of experience. Provide realistic pricing based on industry standards."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      quote: result.quote || 2500,
      breakdown: result.breakdown || "Materials and labor included",
      timeline: result.timeline || "2-3 business days"
    };
  } catch (error) {
    console.error("Error generating quote:", error);
    return {
      quote: 2500,
      breakdown: "Materials and labor included. Final quote may vary based on site inspection.",
      timeline: "2-3 business days"
    };
  }
}

export async function generateSchedulingMessage(availableSlots: string[]): Promise<string> {
  try {
    const prompt = `Generate a professional scheduling message for a tradesman.
    Available time slots: ${availableSlots.join(', ')}
    
    Create a friendly message that:
    1. Offers the available time slots
    2. Asks which time works best
    3. Mentions we can be flexible if needed
    4. Keeps it concise and professional
    
    Return only the message text.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 150,
    });

    return response.choices[0].message.content || `I have availability on ${availableSlots.join(', ')}. Which time works best for you?`;
  } catch (error) {
    console.error("Error generating scheduling message:", error);
    return `I have availability on ${availableSlots.join(', ')}. Which time works best for you? We can also work around your schedule if needed.`;
  }
}
