import { 
  users, jobs, leads, messages, aiAutomation,
  type User, type InsertUser,
  type Job, type InsertJob,
  type Lead, type InsertLead,
  type Message, type InsertMessage,
  type AiAutomation, type InsertAiAutomation
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Jobs
  getJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<InsertJob>): Promise<Job>;
  deleteJob(id: number): Promise<boolean>;

  // Leads
  getLeads(): Promise<Lead[]>;
  getLead(id: number): Promise<Lead | undefined>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLead(id: number, lead: Partial<InsertLead>): Promise<Lead>;
  deleteLead(id: number): Promise<boolean>;

  // Messages
  getMessages(): Promise<Message[]>;
  getMessage(id: number): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByLead(leadId: number): Promise<Message[]>;
  getMessagesByJob(jobId: number): Promise<Message[]>;

  // AI Automation
  getAiAutomations(): Promise<AiAutomation[]>;
  getAiAutomation(id: number): Promise<AiAutomation | undefined>;
  createAiAutomation(automation: InsertAiAutomation): Promise<AiAutomation>;
  updateAiAutomation(id: number, automation: Partial<InsertAiAutomation>): Promise<AiAutomation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobs: Map<number, Job>;
  private leads: Map<number, Lead>;
  private messages: Map<number, Message>;
  private aiAutomations: Map<number, AiAutomation>;
  private currentUserId: number;
  private currentJobId: number;
  private currentLeadId: number;
  private currentMessageId: number;
  private currentAiId: number;

  constructor() {
    this.users = new Map();
    this.jobs = new Map();
    this.leads = new Map();
    this.messages = new Map();
    this.aiAutomations = new Map();
    this.currentUserId = 1;
    this.currentJobId = 1;
    this.currentLeadId = 1;
    this.currentMessageId = 1;
    this.currentAiId = 1;

    // Initialize with default AI automations
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Default AI automations
    this.createAiAutomation({
      name: "Auto Response",
      type: "auto_response",
      enabled: true,
      template: "Thank you for your interest in our services. We'll get back to you within 2 hours with a detailed quote.",
      settings: { responseDelay: 5, businessHoursOnly: true },
      successRate: "94.00",
      usageCount: 47
    });

    this.createAiAutomation({
      name: "Quote Generation",
      type: "quote_generation",
      enabled: true,
      template: "Based on your requirements, here's your estimated quote: {quote}",
      settings: { includeDiscount: true, validityDays: 30 },
      successRate: "89.00",
      usageCount: 23
    });

    this.createAiAutomation({
      name: "Smart Scheduling",
      type: "scheduling",
      enabled: true,
      template: "I have availability on {dates}. Which time works best for you?",
      settings: { bufferTime: 30, workingHours: "9-17" },
      successRate: "91.00",
      usageCount: 15
    });

    // Sample Jobs with GPS data
    this.createJob({
      clientName: "Sarah Johnson",
      clientEmail: "sarah.johnson@email.com",
      clientPhone: "(555) 123-4567",
      service: "Bathroom Leak Repair",
      description: "Emergency leak under bathroom sink, customer available weekends",
      status: "scheduled",
      value: "285",
      scheduledDate: new Date("2025-06-28T09:00:00Z"),
      address: "123 Oak Street",
      city: "Austin",
      state: "TX",
      zipCode: "78701",
      latitude: "30.2672",
      longitude: "-97.7431",
      estimatedDuration: 90
    });

    this.createJob({
      clientName: "Mike Chen",
      clientEmail: "mike.chen@email.com",
      clientPhone: "(555) 234-5678",
      service: "Kitchen Renovation",
      description: "Complete kitchen renovation including cabinets, countertops, and appliances",
      status: "completed",
      value: "1500",
      scheduledDate: new Date("2025-06-20T08:00:00Z"),
      address: "456 Pine Avenue",
      city: "Austin",
      state: "TX",
      zipCode: "78704",
      latitude: "30.2500",
      longitude: "-97.7600",
      estimatedDuration: 480
    });

    this.createJob({
      clientName: "Emma Wilson",
      clientEmail: "emma.wilson@email.com",
      clientPhone: "(555) 345-6789",
      service: "Boiler Service",
      description: "Annual boiler service and maintenance check",
      status: "completed",
      value: "150",
      scheduledDate: new Date("2025-06-15T10:00:00Z"),
      address: "789 Elm Drive",
      city: "Austin",
      state: "TX",
      zipCode: "78702",
      latitude: "30.2800",
      longitude: "-97.7200",
      estimatedDuration: 60
    });

    this.createJob({
      clientName: "David Thompson",
      clientEmail: "david.thompson@email.com",
      clientPhone: "(555) 456-7890",
      service: "Electrical Outlet Installation",
      description: "Install 3 new electrical outlets in home office",
      status: "completed",
      value: "350",
      scheduledDate: new Date("2025-06-30T14:00:00Z"),
      address: "321 Maple Lane",
      city: "Austin",
      state: "TX",
      zipCode: "78703",
      latitude: "30.2900",
      longitude: "-97.7300",
      estimatedDuration: 120
    });

    // Additional completed jobs to reach $4,500 monthly revenue
    this.createJob({
      clientName: "Jennifer Martinez",
      clientEmail: "jennifer.martinez@email.com",
      clientPhone: "(555) 567-8901",
      service: "Bathroom Renovation",
      description: "Full bathroom renovation with new tiles and fixtures",
      status: "completed",
      value: "700",
      scheduledDate: new Date("2025-06-18T09:00:00Z"),
      address: "555 Cedar Street",
      city: "Austin",
      state: "TX",
      zipCode: "78705",
      latitude: "30.2950",
      longitude: "-97.7350",
      estimatedDuration: 360
    });

    this.createJob({
      clientName: "Robert Kim",
      clientEmail: "robert.kim@email.com", 
      clientPhone: "(555) 678-9012",
      service: "Fence Installation",
      description: "Install privacy fence around backyard perimeter",
      status: "completed",
      value: "100",
      scheduledDate: new Date("2025-06-12T08:00:00Z"),
      address: "777 Birch Avenue",
      city: "Austin",
      state: "TX",
      zipCode: "78706",
      latitude: "30.3000",
      longitude: "-97.7400",
      estimatedDuration: 240
    });

    // Sample Leads
    this.createLead({
      name: "Lisa Brown",
      email: "lisa.brown@email.com",
      phone: "07444555666",
      service: "Heating System Repair",
      estimatedValue: "450",
      status: "new",
      source: "Google Ads",
      responseRate: 0,
      notes: "Radiator not heating properly in living room"
    });

    this.createLead({
      name: "James Wilson",
      email: "james.wilson@email.com",
      phone: "07555666777",
      service: "Plumbing Emergency",
      estimatedValue: "200",
      status: "contacted",
      source: "Facebook",
      responseRate: 85,
      notes: "Blocked drain in kitchen sink"
    });

    this.createLead({
      name: "Rachel Green",
      email: "rachel.green@email.com",
      phone: "07666777888",
      service: "Roof Tile Replacement",
      estimatedValue: "800",
      status: "qualified",
      source: "Referral",
      responseRate: 95,
      notes: "Storm damage to roof tiles, insurance claim approved"
    });

    this.createLead({
      name: "Tom Anderson",
      email: "tom.anderson@email.com",
      phone: "07777888999",
      service: "Garden Shed Construction",
      estimatedValue: "1200",
      status: "warm",
      source: "Website",
      responseRate: 70,
      notes: "Looking for custom shed 10x8 ft with electricity"
    });

    // Sample Messages
    this.createMessage({
      sender: "TradeFlow Pro",
      recipient: "lisa.brown@email.com",
      subject: "Thank you for your heating inquiry",
      content: "Hi Lisa, thank you for reaching out about your heating system repair. I understand your radiator isn't heating properly in the living room. I can come take a look this week and provide you with a detailed quote. I have availability on Wednesday afternoon or Friday morning. Which works better for you?",
      type: "ai_sent",
      leadId: 1,
      status: "sent"
    });

    this.createMessage({
      sender: "TradeFlow Pro",
      recipient: "james.wilson@email.com",
      subject: "Quick response to your plumbing emergency",
      content: "Hi James, I received your message about the blocked kitchen drain. For urgent plumbing issues like this, I can usually get to you within 24 hours. My quote for drain unblocking is typically £150-200 depending on the severity. I can come by tomorrow morning if that works for you?",
      type: "ai_sent",
      leadId: 2,
      status: "delivered"
    });

    this.createMessage({
      sender: "TradeFlow Pro",
      recipient: "sarah.johnson@email.com",
      subject: "Your bathroom leak repair quote",
      content: "Hi Sarah, following our conversation about the bathroom leak, I can fix this for £285 including parts and labor. This covers the pipe repair, new fittings, and a full check of surrounding plumbing. I'm available this Saturday morning or Sunday afternoon. Which suits you better?",
      type: "ai_generated",
      jobId: 1,
      status: "sent"
    });

    this.createMessage({
      sender: "TradeFlow Pro",
      recipient: "rachel.green@email.com",
      subject: "Roof tile replacement estimate",
      content: "Hi Rachel, thank you for contacting me about your roof tile replacement following the storm damage. Since your insurance claim is approved, I can work directly with them. My estimate for replacing the damaged tiles is £750-850 depending on the exact tiles needed to match your roof. I can start as early as next week weather permitting.",
      type: "ai_sent",
      leadId: 3,
      status: "read"
    });

    this.createMessage({
      sender: "Mike Chen",
      recipient: "traderpro@email.com",
      subject: "Kitchen renovation progress update",
      content: "Hi, just wanted to check on the progress of our kitchen renovation. The demolition looks great so far. When do you expect to start on the cabinet installation?",
      type: "manual",
      jobId: 2,
      status: "received"
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      name: insertUser.username,
      email: `${insertUser.username}@example.com`
    };
    this.users.set(id, user);
    return user;
  }

  // Jobs
  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentJobId++;
    const job: Job = {
      id,
      clientName: insertJob.clientName,
      clientEmail: insertJob.clientEmail,
      clientPhone: insertJob.clientPhone || null,
      service: insertJob.service,
      description: insertJob.description || null,
      status: insertJob.status || "scheduled",
      value: insertJob.value,
      scheduledDate: insertJob.scheduledDate || null,
      address: insertJob.address || null,
      city: insertJob.city || null,
      state: insertJob.state || null,
      zipCode: insertJob.zipCode || null,
      latitude: insertJob.latitude || null,
      longitude: insertJob.longitude || null,
      estimatedDuration: insertJob.estimatedDuration || null,
      createdAt: new Date(),
    };
    this.jobs.set(id, job);
    return job;
  }

  async updateJob(id: number, jobUpdate: Partial<InsertJob>): Promise<Job> {
    const existing = this.jobs.get(id);
    if (!existing) {
      throw new Error(`Job with id ${id} not found`);
    }
    const updated = { ...existing, ...jobUpdate };
    this.jobs.set(id, updated);
    return updated;
  }

  async deleteJob(id: number): Promise<boolean> {
    return this.jobs.delete(id);
  }

  // Leads
  async getLeads(): Promise<Lead[]> {
    return Array.from(this.leads.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getLead(id: number): Promise<Lead | undefined> {
    return this.leads.get(id);
  }

  async createLead(insertLead: InsertLead): Promise<Lead> {
    const id = this.currentLeadId++;
    const lead: Lead = {
      id,
      name: insertLead.name,
      email: insertLead.email,
      phone: insertLead.phone || null,
      service: insertLead.service,
      estimatedValue: insertLead.estimatedValue || null,
      status: insertLead.status || "new",
      source: insertLead.source || null,
      responseRate: insertLead.responseRate || null,
      notes: insertLead.notes || null,
      createdAt: new Date(),
    };
    this.leads.set(id, lead);
    return lead;
  }

  async updateLead(id: number, leadUpdate: Partial<InsertLead>): Promise<Lead> {
    const existing = this.leads.get(id);
    if (!existing) {
      throw new Error(`Lead with id ${id} not found`);
    }
    const updated = { ...existing, ...leadUpdate };
    this.leads.set(id, updated);
    return updated;
  }

  async deleteLead(id: number): Promise<boolean> {
    return this.leads.delete(id);
  }

  // Messages
  async getMessages(): Promise<Message[]> {
    return Array.from(this.messages.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      id,
      sender: insertMessage.sender,
      recipient: insertMessage.recipient,
      subject: insertMessage.subject || null,
      content: insertMessage.content,
      type: insertMessage.type || "manual",
      leadId: insertMessage.leadId || null,
      jobId: insertMessage.jobId || null,
      status: insertMessage.status || "sent",
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesByLead(leadId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(msg => msg.leadId === leadId)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }

  async getMessagesByJob(jobId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(msg => msg.jobId === jobId)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }

  // AI Automation
  async getAiAutomations(): Promise<AiAutomation[]> {
    return Array.from(this.aiAutomations.values());
  }

  async getAiAutomation(id: number): Promise<AiAutomation | undefined> {
    return this.aiAutomations.get(id);
  }

  async createAiAutomation(insertAiAutomation: InsertAiAutomation): Promise<AiAutomation> {
    const id = this.currentAiId++;
    const automation: AiAutomation = {
      id,
      name: insertAiAutomation.name,
      type: insertAiAutomation.type,
      enabled: insertAiAutomation.enabled !== undefined ? insertAiAutomation.enabled : true,
      template: insertAiAutomation.template || null,
      settings: insertAiAutomation.settings || null,
      successRate: insertAiAutomation.successRate || null,
      usageCount: insertAiAutomation.usageCount || null,
    };
    this.aiAutomations.set(id, automation);
    return automation;
  }

  async updateAiAutomation(id: number, automationUpdate: Partial<InsertAiAutomation>): Promise<AiAutomation> {
    const existing = this.aiAutomations.get(id);
    if (!existing) {
      throw new Error(`AI Automation with id ${id} not found`);
    }
    const updated = { ...existing, ...automationUpdate };
    this.aiAutomations.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
