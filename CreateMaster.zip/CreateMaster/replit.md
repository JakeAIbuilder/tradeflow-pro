# TradeFlow - Job Management & Lead Automation Platform

## Overview

TradeFlow is a comprehensive job management and lead automation platform designed for tradesmen and service businesses. The application helps businesses manage their jobs, track leads, automate customer communications using AI, and gain insights through analytics. Built as a full-stack application with a React frontend and Express backend, it leverages PostgreSQL for data persistence and integrates OpenAI for intelligent automation features.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless adapter
- **AI Integration**: OpenAI API for automated response generation and quote creation
- **Session Management**: Express sessions with PostgreSQL storage

### Database Architecture
- **Primary Database**: PostgreSQL 16
- **ORM**: Drizzle ORM with migrations support
- **Schema**: Centralized schema definition in `/shared/schema.ts`
- **Tables**: Users, Jobs, Leads, Messages with proper relationships

## Key Components

### Data Models
1. **Users**: Authentication and user management
2. **Jobs**: Core job tracking with client info, services, status, and scheduling
3. **Leads**: Lead management with status tracking and source attribution
4. **Messages**: Communication history with AI automation capabilities

### Frontend Components
- **Dashboard**: Main interface with metrics cards and tabbed views
- **Layout System**: Responsive sidebar and topbar navigation
- **Form Components**: Reusable forms with validation
- **UI Components**: Comprehensive design system using Shadcn/ui

### Backend Services
- **Storage Layer**: Abstract storage interface with memory implementation for development
- **AI Services**: OpenAI integration for automated responses and quote generation
- **Route Handlers**: RESTful API endpoints for all data operations

## Data Flow

1. **Client Requests**: Frontend makes API calls through TanStack Query
2. **API Layer**: Express routes handle requests with proper validation
3. **Business Logic**: Service layer processes business rules
4. **Data Persistence**: Drizzle ORM manages database operations
5. **Real-time Updates**: Query invalidation ensures fresh data
6. **AI Integration**: OpenAI services generate intelligent responses when triggered

## External Dependencies

### Core Dependencies
- **Database**: Neon serverless PostgreSQL
- **AI Services**: OpenAI API for text generation
- **UI Framework**: Radix UI primitives for accessible components
- **Validation**: Zod for runtime type checking and validation
- **Date Handling**: date-fns for date manipulation

### Development Tools
- **TypeScript**: Full type safety across the stack
- **Vite**: Fast development server and build tool
- **ESBuild**: Production server bundling
- **Drizzle Kit**: Database migration management

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

### Development Environment
- **Command**: `npm run dev` - Runs both frontend and backend in development mode
- **Port**: 5000 for the Express server with Vite middleware
- **Hot Reload**: Vite provides HMR for frontend, tsx for backend restart

### Production Environment
- **Build Process**: 
  1. `vite build` - Builds optimized frontend assets
  2. `esbuild` - Bundles backend into single file
- **Runtime**: `npm start` - Runs production server
- **Static Assets**: Frontend built to `dist/public`, served by Express

### Database Setup
- **Development**: Uses DATABASE_URL environment variable
- **Migrations**: `npm run db:push` applies schema changes
- **Provider**: Neon serverless PostgreSQL for scalability

## Changelog

- June 25, 2025. Initial setup and TradeFlow Pro implementation complete
- Added comprehensive AI automation system with OpenAI integration
- Implemented job management, lead tracking, and automated messaging
- Created responsive dashboard with real-time metrics and analytics
- Successfully tested lead conversion and AI fallback systems
- Added GPS route planning functionality with real geocoding API
  - Integrated OpenStreetMap Nominatim for address geocoding
  - Implemented route optimization using nearest neighbor algorithm
  - Added job form address fields for location tracking
  - Created interactive route planner with fuel cost estimation
  - Built API endpoints for geocoding and route optimization

## User Preferences

Preferred communication style: Simple, everyday language.
Project focus: AI-powered business automation for tradesmen
Demonstration preference: Interactive exploration of features