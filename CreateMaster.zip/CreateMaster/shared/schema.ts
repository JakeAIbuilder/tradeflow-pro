import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email").notNull(),
  clientPhone: text("client_phone"),
  service: text("service").notNull(),
  description: text("description"),
  status: text("status").notNull().default("scheduled"), // scheduled, in_progress, completed, cancelled
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  scheduledDate: timestamp("scheduled_date"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  estimatedDuration: integer("estimated_duration"), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
});

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  service: text("service").notNull(),
  estimatedValue: decimal("estimated_value", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("new"), // new, contacted, qualified, hot, warm, cold, converted, lost
  source: text("source"), // google_ads, facebook, website, referral
  responseRate: integer("response_rate").default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  sender: text("sender").notNull(),
  recipient: text("recipient").notNull(),
  subject: text("subject"),
  content: text("content").notNull(),
  type: text("type").notNull().default("manual"), // manual, ai_sent, ai_generated
  leadId: integer("lead_id"),
  jobId: integer("job_id"),
  status: text("status").notNull().default("sent"), // sent, delivered, read, replied
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiAutomation = pgTable("ai_automation", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // auto_response, quote_generation, scheduling
  enabled: boolean("enabled").default(true),
  template: text("template"),
  settings: jsonb("settings"),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).default("0"),
  usageCount: integer("usage_count").default(0),
});

// Insert schemas
export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
}).extend({
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  clientPhone: z.string().optional(),
});

export const insertLeadSchema = createInsertSchema(leads).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertAiAutomationSchema = createInsertSchema(aiAutomation).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type AiAutomation = typeof aiAutomation.$inferSelect;
export type InsertAiAutomation = z.infer<typeof insertAiAutomationSchema>;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
